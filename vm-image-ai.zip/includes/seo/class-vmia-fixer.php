<?php
/**
 * Applies fixes for detected image-SEO issues. Powers the one-click per-issue
 * fix and the bulk "God Fix" autopilot.
 *
 * @package VM_Image_AI
 */

defined( 'ABSPATH' ) || exit;

class VMIA_Fixer {

	/**
	 * Fix a single audit row by id.
	 *
	 * @param int $audit_id
	 * @return array { ok, message }
	 */
	public function fix_by_id( $audit_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'vmia_audit';
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", $audit_id ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			return array( 'ok' => false, 'message' => 'Issue not found' );
		}
		return $this->fix_row( $row );
	}

	/**
	 * @param array $row Audit row.
	 * @return array
	 */
	public function fix_row( $row ) {
		$code   = $row['issue_code'];
		$obj_id = (int) $row['object_id'];
		$result = array( 'ok' => false, 'message' => 'No handler' );

		switch ( $code ) {
			case 'missing_alt':
			case 'short_alt':
			case 'filename_alt':
			case 'filename_title':
			case 'missing_caption':
			case 'bad_filename':
			case 'duplicate_alt':
			case 'keyword_gap':
				$post_id = (int) wp_get_post_parent_id( $obj_id );
				( new VMIA_SEO_Writer() )->write_for_attachment( $obj_id, $post_id, array( 'overwrite' => true ) );
				$result = array( 'ok' => true, 'message' => 'Rewrote SEO metadata' );
				break;

			case 'oversized_file':
			case 'oversized_dim':
			case 'legacy_format':
				$res = ( new VMIA_Resize() )->optimize_attachment( $obj_id );
				$result = ! empty( $res['ok'] )
					? array( 'ok' => true, 'message' => sprintf( 'Optimised %s → %s', size_format( $res['before'] ), size_format( $res['after'] ) ) )
					: array( 'ok' => false, 'message' => $res['error'] ?? 'resize failed' );
				break;

			case 'no_featured':
			case 'no_images':
				$result = $this->fix_no_featured( (int) $row['post_id'] );
				break;

			case 'content_img_no_alt':
				$result = $this->fix_content_alts( (int) $row['post_id'] );
				break;

			case 'content_404':
				$result = $this->fix_content_404( (int) $row['post_id'] );
				break;

			case 'broken_file':
				$result = $this->regenerate_image_for_audit( (int) $row['id'] );
				break;
		}

		if ( ! empty( $result['ok'] ) ) {
			$this->resolve( (int) $row['id'] );
		} else {
			$this->mark_failed( (int) $row['id'] );
		}
		return $result;
	}

	/**
	 * Generate + attach a featured image for a post lacking one.
	 */
	protected function fix_no_featured( $post_id ) {
		if ( ! $post_id ) {
			return array( 'ok' => false, 'message' => 'no post' );
		}
		$title = get_the_title( $post_id );
		$res   = ( new VMIA_Image_Router() )->generate_to_library(
			$title,
			array(
				'post_id'      => $post_id,
				'set_featured' => true,
				'width'        => (int) VMIA_Settings::get( 'featured_w', 1200 ),
				'height'       => (int) VMIA_Settings::get( 'featured_h', 630 ),
				'title'        => $title,
			)
		);
		return ! empty( $res['ok'] )
			? array( 'ok' => true, 'message' => 'Generated featured image via ' . $res['provider'] )
			: array( 'ok' => false, 'message' => $res['error'] ?? 'generation failed' );
	}

	/**
	 * Fill missing alt attributes inside a post's content.
	 */
	protected function fix_content_alts( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return array( 'ok' => false, 'message' => 'no post' );
		}
		$content = $post->post_content;
		$title   = get_the_title( $post_id );
		$fixed   = 0;

		$content = preg_replace_callback(
			'/<img\b[^>]*>/i',
			function ( $m ) use ( &$fixed, $title, $post_id ) {
				$tag = $m[0];
				if ( preg_match( '/\balt\s*=\s*(["\'])(.*?)\1/i', $tag, $a ) && '' !== trim( $a[2] ) ) {
					return $tag; // already has alt.
				}
				// Resolve attachment id from wp-image-XX to reuse/generate its alt.
				$alt = '';
				if ( preg_match( '/wp-image-(\d+)/', $tag, $idm ) ) {
					$aid = (int) $idm[1];
					$alt = trim( (string) get_post_meta( $aid, '_wp_attachment_image_alt', true ) );
					if ( '' === $alt && VMIA_Settings::has_text_ai() ) {
						$data = ( new VMIA_SEO_Writer() )->write_for_attachment( $aid, $post_id, array( 'overwrite' => false ) );
						$alt  = $data['alt'] ?? '';
					}
				}
				if ( '' === $alt ) {
					$alt = $title; // last-resort contextual alt.
				}
				$alt   = esc_attr( $alt );
				$fixed++;
				if ( preg_match( '/\balt\s*=\s*(["\']).*?\1/i', $tag ) ) {
					return preg_replace( '/\balt\s*=\s*(["\']).*?\1/i', 'alt="' . $alt . '"', $tag );
				}
				return preg_replace( '/<img\b/i', '<img alt="' . $alt . '"', $tag, 1 );
			},
			$content
		);

		if ( $fixed > 0 ) {
			wp_update_post( array( 'ID' => $post_id, 'post_content' => $content ) );
			return array( 'ok' => true, 'message' => sprintf( 'Added alt to %d image(s)', $fixed ) );
		}
		return array( 'ok' => true, 'message' => 'Nothing to change' );
	}

	/**
	 * Replace dead/missing in-content <img> src attributes with a freshly
	 * generated AI image, re-verifying each one at fix time since the audit
	 * row doesn't track individual URLs.
	 */
	protected function fix_content_404( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return array( 'ok' => false, 'message' => 'no post' );
		}

		$content = $post->post_content;
		$title   = get_the_title( $post_id );
		$auditor = new VMIA_Auditor();
		$router  = new VMIA_Image_Router();
		$fixed   = 0;
		$failed  = 0;

		$content = preg_replace_callback(
			'/<img\b[^>]*>/i',
			function ( $m ) use ( &$fixed, &$failed, $title, $post_id, $auditor, $router ) {
				$tag = $m[0];
				if ( ! preg_match( '/\bsrc\s*=\s*(["\'])(.*?)\1/i', $tag, $sm ) ) {
					return $tag;
				}
				if ( ! $auditor->url_is_broken( $sm[2] ) ) {
					return $tag; // Still fine.
				}

				preg_match( '/\balt\s*=\s*(["\'])(.*?)\1/i', $tag, $am );
				$subject = ! empty( $am[2] ) ? $am[2] : $title;

				$res = $router->generate_to_library( $subject, array(
					'post_id' => $post_id,
					'title'   => $subject,
				) );

				if ( empty( $res['ok'] ) ) {
					$failed++;
					return $tag; // Leave in place; will resurface on the next scan.
				}

				$fixed++;
				$new_tag = preg_replace( '/\bsrc\s*=\s*(["\']).*?\1/i', 'src="' . esc_url( $res['url'] ) . '"', $tag, 1 );
				// Strip stale srcset and sizes attributes so the browser loads the new image.
				$new_tag = preg_replace( '/\b(srcset|sizes)\s*=\s*(["\']).*?\2/i', '', $new_tag );
				return $new_tag;
			},
			$content
		);

		if ( $fixed > 0 ) {
			wp_update_post( array( 'ID' => $post_id, 'post_content' => $content ) );
			return $failed > 0
				? array( 'ok' => true, 'message' => sprintf( 'Replaced %d broken image(s); %d could not be regenerated', $fixed, $failed ) )
				: array( 'ok' => true, 'message' => sprintf( 'Replaced %d broken image(s) with new AI generation', $fixed ) );
		}

		return array( 'ok' => false, 'message' => 'Could not regenerate broken image(s)' );
	}

	/**
	 * Bulk autopilot. Processes up to $batch open issues (highest severity first).
	 *
	 * @param int $batch
	 * @return array { processed, fixed, remaining, results[] }
	 */
	public function god_fix( $batch = 0 ) {
		$batch = $batch ?: (int) VMIA_Settings::get( 'god_fix_batch', 15 );
		$rows  = VMIA_Auditor::open_issues( $batch );
		$out   = array( 'processed' => 0, 'fixed' => 0, 'results' => array() );

		foreach ( $rows as $row ) {
			$res = $this->fix_row( $row );
			$out['processed']++;
			if ( ! empty( $res['ok'] ) ) {
				$out['fixed']++;
			}
			$out['results'][] = array(
				'code'    => $row['issue_code'],
				'object'  => (int) $row['object_id'],
				'ok'      => ! empty( $res['ok'] ),
				'message' => $res['message'],
			);
		}

		$out['remaining'] = array_sum( VMIA_Auditor::summary() );
		VMIA_Logger::add( 'fix', 0, 'godfix', sprintf( 'God Fix batch: %d/%d fixed, %d remaining', $out['fixed'], $out['processed'], $out['remaining'] ) );
		return $out;
	}

	public function resolve_audit_by_id( $audit_id ) {
		$this->resolve( (int) $audit_id );
	}

	/**
	 * Completely replace a broken or undesired image with a new AI generation.
	 *
	 * @param int $audit_id
	 * @return array
	 */
	public function regenerate_image_for_audit( $audit_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'vmia_audit';
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", $audit_id ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			return array( 'ok' => false, 'message' => 'Audit entry not found' );
		}

		$obj_id  = (int) $row['object_id'];
		$post_id = (int) $row['post_id'];
		if ( ! $post_id ) {
			$post_id = (int) wp_get_post_parent_id( $obj_id );
		}

		$subject = $post_id ? get_the_title( $post_id ) : 'Professional blog image';

		// 1. Generate new image.
		$router = new VMIA_Image_Router();
		$res = $router->generate_to_library( $subject, array(
			'post_id'      => $post_id,
			'set_featured' => ( 'no_featured' === $row['issue_code'] || has_post_thumbnail( $post_id ) && get_post_thumbnail_id( $post_id ) == $obj_id ),
			'width'        => (int) VMIA_Settings::get( 'featured_w', 1200 ),
			'height'       => (int) VMIA_Settings::get( 'featured_h', 630 ),
		) );

		if ( ! empty( $res['ok'] ) ) {
			// 2. If it was an existing attachment that we replaced, delete the old one to avoid clutter.
			if ( $obj_id && $obj_id !== (int) ( $res['attach_id'] ?? 0 ) ) {
				wp_delete_attachment( $obj_id, true );
			}
			$this->resolve( $audit_id );
			return array( 'ok' => true, 'message' => 'Image replaced with new AI generation' );
		}

		return array( 'ok' => false, 'message' => $res['error'] ?? 'Generation failed' );
	}

	/**
	 * Apply a specific bulk action to multiple audit rows.
	 *
	 * @param array  $ids    Audit row IDs.
	 * @param string $action 'fix' (AI Metadata) or 'optimize'.
	 * @return array
	 */
	public function bulk_fix( $ids, $action ) {
		$results = array( 'fixed' => 0, 'failed' => 0, 'messages' => array() );
		global $wpdb;
		$table = $wpdb->prefix . 'vmia_audit';

		foreach ( $ids as $id ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", (int) $id ), ARRAY_A ); // phpcs:ignore
			if ( ! $row ) continue;

			$res = array( 'ok' => false );

			if ( 'fix' === $action ) {
				$res = $this->fix_row( $row );
			} elseif ( 'optimize' === $action ) {
				$res = ( new VMIA_Resize() )->optimize_attachment( (int) $row['object_id'] );
				if ( ! empty( $res['ok'] ) ) {
					$this->resolve( (int) $id );
				} else {
					$this->mark_failed( (int) $id );
				}
			}

			if ( ! empty( $res['ok'] ) ) {
				$results['fixed']++;
			} else {
				$results['failed']++;
			}
		}

		return $results;
	}

	protected function resolve( $audit_id ) {
		global $wpdb;
		$wpdb->update(
			$wpdb->prefix . 'vmia_audit',
			array( 'status' => 'resolved', 'resolved_at' => current_time( 'mysql' ) ),
			array( 'id' => $audit_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	protected function mark_failed( $audit_id ) {
		global $wpdb;
		$wpdb->update(
			$wpdb->prefix . 'vmia_audit',
			array( 'status' => 'failed' ),
			array( 'id' => $audit_id ),
			array( '%s' ),
			array( '%d' )
		);
	}
}
